<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Himalaya Ecom</title>
</head>
<body>
    <h1>Testing Application OTP</h1>

    <h1>{{ $otp }}</h1>

 

    <p>Thank You.</p>

</body>
</html>