<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Himalaya Ecom</title>
</head>
<body>
    <h1>Testing Application OTP</h1>

    <h1><?php echo e($otp); ?></h1>

 

    <p>Thank You.</p>

</body>
</html><?php /**PATH /home/sushilpulseplay/Documents/GitHub/ecommerce-app/resources/views/emails/otpEmail.blade.php ENDPATH**/ ?>